doubleClick("1508175934795.png")
wait("1508175971518.png",5)
click("1508175986183.png")
wait("1508178061716.png",5)
click("1508178069606.png")
type("1508178092674.png", '3')
type("1508178104901.png", '3')
click("1508178117730.png")
click("1508176854937.png")
wait("1508176871151.png",5)
click(Pattern("1508176894133.png").targetOffset(-158,-22))
click("1508176912571.png")
click("1508177003290.png")
click("1508177011344.png")
click("1508177020774.png")















